# -*- coding: utf-8 -*-
"""
lear_python_ceg
Authors: Miguel Angel Mendoza-Lugo, Robert Lanzafame, Ahmed Farahat

E-mail:  m.a.mendozalugo@tudelft.nl, R.C.Lanzafame@tudelft.nl, A.Farahat@student.tudelft.nl
"""
from __future__ import absolute_import

from . import check_answers

