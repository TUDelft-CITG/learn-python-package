# learn_python_ceg_test

**This is a test!**

In this repository the functions to check answers of the jupyterbook learn pyhton ceg are hosted. 
---
M i k e ! ! ! 
